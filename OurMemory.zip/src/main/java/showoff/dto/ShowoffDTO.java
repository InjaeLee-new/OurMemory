package showoff.dto;


public class ShowoffDTO {
	private int board_num;
	private String board_name;
	private String board_id;
	private String board_pass;
	private String board_subject;
	private String board_content;
	private int board_rec;
	private int board_nrec;
	private int board_hit;
	private String board_file;
	private String board_date;
	
	public int getBoard_rec() {
		return board_rec;
	}
	public void setBoard_rec(int board_rec) {
		this.board_rec = board_rec;
	}
	public int getBoard_nrec() {
		return board_nrec;
	}
	public void setBoard_nrec(int board_nrec) {
		this.board_nrec = board_nrec;
	}
	public int getBoard_hit() {
		return board_hit;
	}
	public void setBoard_hit(int board_hit) {
		this.board_hit = board_hit;
	}
	
	public int getBoard_num() {
		return board_num;
	}
	public void setBoard_num(int board_num) {
		this.board_num = board_num;
	}
	public String getBoard_name() {
		return board_name;
	}
	public void setBoard_name(String board_name) {
		this.board_name = board_name;
	}
	public String getBoard_id() {
		return board_id;
	}
	public void setBoard_id(String board_id) {
		this.board_id = board_id;
	}
	public String getBoard_pass() {
		return board_pass;
	}
	public void setBoard_pass(String board_pass) {
		this.board_pass = board_pass;
	}
	public String getBoard_subject() {
		return board_subject;
	}
	public void setBoard_subject(String board_subject) {
		this.board_subject = board_subject;
	}
	public String getBoard_content() {
		return board_content;
	}
	public void setBoard_content(String board_content) {
		this.board_content = board_content;
	}
	public String getBoard_file() {
		return board_file;
	}
	public void setBoard_file(String board_file) {
		this.board_file = board_file;
	}
	public String getBoard_date() {
		return board_date;
	}
	public void setBoard_date(String board_date) {
		this.board_date = board_date;
	}
	
	
}
