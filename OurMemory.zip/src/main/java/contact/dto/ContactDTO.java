package contact.dto;

public class ContactDTO {
	private String contact_name;
	private String contact_id; 
	private String contact_pwd; 
	private String contact_email1; 
	private String contact_email2; 
	private String contact_tel1; 
	private String contact_tel2; 
	private String contact_tel3; 
	private String contact_reason; 
	private String contact_callback; 
	private String contact_subject; 
	private String contact_content; 
	private String contact_logtime;
	
	public String getContact_name() {
		return contact_name;
	}
	public void setContact_name(String contact_name) {
		this.contact_name = contact_name;
	}
	public String getContact_id() {
		return contact_id;
	}
	public void setContact_id(String contact_id) {
		this.contact_id = contact_id;
	}
	public String getContact_pwd() {
		return contact_pwd;
	}
	public void setContact_pwd(String contact_pwd) {
		this.contact_pwd = contact_pwd;
	}
	public String getContact_email1() {
		return contact_email1;
	}
	public void setContact_email1(String contact_email1) {
		this.contact_email1 = contact_email1;
	}
	public String getContact_email2() {
		return contact_email2;
	}
	public void setContact_email2(String contact_email2) {
		this.contact_email2 = contact_email2;
	}
	public String getContact_tel1() {
		return contact_tel1;
	}
	public void setContact_tel1(String contact_tel1) {
		this.contact_tel1 = contact_tel1;
	}
	public String getContact_tel2() {
		return contact_tel2;
	}
	public void setContact_tel2(String contact_tel2) {
		this.contact_tel2 = contact_tel2;
	}
	public String getContact_tel3() {
		return contact_tel3;
	}
	public void setContact_tel3(String contact_tel3) {
		this.contact_tel3 = contact_tel3;
	}
	public String getContact_reason() {
		return contact_reason;
	}
	public void setContact_reason(String contact_reason) {
		this.contact_reason = contact_reason;
	}
	public String getContact_callback() {
		return contact_callback;
	}
	public void setContact_callback(String contact_callback) {
		this.contact_callback = contact_callback;
	}
	public String getContact_subject() {
		return contact_subject;
	}
	public void setContact_subject(String contact_subject) {
		this.contact_subject = contact_subject;
	}
	public String getContact_content() {
		return contact_content;
	}
	public void setContact_content(String contact_content) {
		this.contact_content = contact_content;
	}
	public String getContact_logtime() {
		return contact_logtime;
	}
	public void setContact_logtime(String contact_logtime) {
		this.contact_logtime = contact_logtime;
	} 
	
	

}
